package com.medapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedappApplicationTests {

	@Test
	void contextLoads() {
	}

}
