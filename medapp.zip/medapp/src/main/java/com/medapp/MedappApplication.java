package com.medapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedappApplication.class, args);
	}

}
