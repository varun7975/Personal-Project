package com.medapp.model;

import java.util.List;

import com.medapp.entities.Patient;

public interface PatientServices {
	
	public void savePatient(Patient patient);
	
	public List<Patient> findAllPatient();

	public Patient getById(long id);

	public void deleteById(long id);
	

}
