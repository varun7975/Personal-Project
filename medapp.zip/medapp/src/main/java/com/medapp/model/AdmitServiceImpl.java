package com.medapp.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medapp.entities.Admit;
import com.medapp.repositories.AdmitRepository;

@Service
public class AdmitServiceImpl implements AdmitService {
	
	@Autowired
	private AdmitRepository admitRepo;
	
	@Override
	public void saveAdmit(Admit admit) {
		admitRepo.save(admit);

	}

	@Override
	public List<Admit> getAll() {
		List<Admit> admit = admitRepo.findAll();
		return admit;
	}

}
