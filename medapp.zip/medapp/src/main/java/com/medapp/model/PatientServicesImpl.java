package com.medapp.model;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medapp.entities.Patient;
import com.medapp.repositories.PatientRepository;

@Service
public class PatientServicesImpl implements PatientServices {

	@Autowired
	private PatientRepository patientRepo;

	@Override
	public void savePatient(Patient patient) {
		try {
			patientRepo.save(patient);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<Patient> findAllPatient() {
		List<Patient> patients = patientRepo.findAll();
		return patients;
	}

	@Override
	public Patient getById(long id) {
		Optional<Patient> findById = patientRepo.findById(id);
		Patient patient = findById.get();
		return patient;
	}

	@Override
	public void deleteById(long id) {
		patientRepo.deleteById(id);
		
	}

	
}
