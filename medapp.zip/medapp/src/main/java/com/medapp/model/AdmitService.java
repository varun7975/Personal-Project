package com.medapp.model;

import java.util.List;

import com.medapp.entities.Admit;


public interface AdmitService {
	
	public void saveAdmit(Admit admit);

	public List<Admit> getAll();

}
