package com.medapp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.medapp.entities.Admit;
@Repository
public interface AdmitRepository extends JpaRepository<Admit, Long> {

}
