package com.medapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.medapp.entities.Admit;
import com.medapp.entities.Patient;
import com.medapp.model.PatientServices;

@Controller
public class PatientController {
	
	@Autowired
	private PatientServices patientServ;
	
	@Autowired
	private AdmitController admitControl;
	
	
	@RequestMapping("view")
	public String viewCreatePage() {
		
		return "patient_admit";
	}
	
	@RequestMapping("savePatient")
	public String saveOnePatient(@ModelAttribute("patient") Patient patient, ModelMap model) {
		patientServ.savePatient(patient);
		model.addAttribute("patient", patient);
		System.out.println("Created");
		return "patient_info";
	}

	@RequestMapping("list")
	public String listAllLeads(ModelMap model) {
		List<Patient> patient = patientServ.findAllPatient();
		model.addAttribute("patient", patient);
		return "patient_list";
	}
	
	@RequestMapping("getPatientById")
	public String findById(@RequestParam("id") long id, ModelMap model) {
		Patient patient = patientServ.getById(id);
		model.addAttribute("patient", patient);
		return "patient_info";
	}
	
	@RequestMapping("delete")
	public String deleteId(@RequestParam("id")long id,ModelMap model) {
		patientServ.deleteById(id);
		List<Patient> patient = patientServ.findAllPatient();
		model.addAttribute("patient", patient);
		return "patient_list";
	}		
	
	@RequestMapping("convert")
	public String convertPatient(@RequestParam("id")long id,ModelMap model) {
		Patient patient = patientServ.getById(id);
		model.addAttribute("patient", patient);
		Admit admit = new Admit();
		admit.setFirstName(patient.getFirstName());
		admit.setLastName(patient.getLastName());
		admit.setEmail(patient.getEmail());
		admit.setAdmitSource(patient.getAdmitSource());
		admit.setMobile(patient.getMobile());
		admit.setDisease(patient.getDisease());
		
		admitControl.admitPatient(admit);
		patientServ.deleteById(id);
		
	List<Admit> admits =	admitControl.findAllAdmit();
	model.addAttribute("admit", admits);
		return "admit_list";
		
	}
	  



}
