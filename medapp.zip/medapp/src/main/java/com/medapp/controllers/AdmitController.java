package com.medapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import com.medapp.entities.Admit;
import com.medapp.model.AdmitService;

@Controller
public class AdmitController {
	
	@Autowired
	private AdmitService admitService;
	

	public void admitPatient(Admit admit) {
		admitService.saveAdmit(admit);
		
	}


	public List<Admit> findAllAdmit() {
		List<Admit> admit = admitService.getAll();
		return admit;
	}
	

}
