package com.medapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.medapp.utilities.EmailService;

@Controller
public class EmailController {
	
	@Autowired
	private EmailService emailService;
	
	@RequestMapping("/compose")
	public String composeEmail(@RequestParam("emailId")String email,ModelMap model) {
		model.addAttribute("email", email);
		return "email_compose";	
	}
		
	@RequestMapping("/sendEmail")
	public String sendEmail(@RequestParam("subject") String subject,@RequestParam("to") String to, @RequestParam("body") String body,Model model) {
		emailService.sendSimpleMessage(to, subject, body);
		model.addAttribute("msg","Email Sent Successfully");
		return "email_compose";
		}
		

}
